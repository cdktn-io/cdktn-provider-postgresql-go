/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPostgresqlSchemasConfig extends cdktn.TerraformMetaArguments {
    /**
    * The PostgreSQL database which will be queried for schema names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas#database DataPostgresqlSchemas#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas#id DataPostgresqlSchemas#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Determines whether to include system schemas (pg_ prefix and information_schema). 'public' will always be included.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas#include_system_schemas DataPostgresqlSchemas#include_system_schemas}
    */
    readonly includeSystemSchemas?: boolean | cdktn.IResolvable;
    /**
    * Expression(s) which will be pattern matched in the query using the PostgreSQL LIKE ALL operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas#like_all_patterns DataPostgresqlSchemas#like_all_patterns}
    */
    readonly likeAllPatterns?: string[];
    /**
    * Expression(s) which will be pattern matched in the query using the PostgreSQL LIKE ANY operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas#like_any_patterns DataPostgresqlSchemas#like_any_patterns}
    */
    readonly likeAnyPatterns?: string[];
    /**
    * Expression(s) which will be pattern matched in the query using the PostgreSQL NOT LIKE ALL operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas#not_like_all_patterns DataPostgresqlSchemas#not_like_all_patterns}
    */
    readonly notLikeAllPatterns?: string[];
    /**
    * Expression which will be pattern matched in the query using the PostgreSQL ~ (regular expression match) operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas#regex_pattern DataPostgresqlSchemas#regex_pattern}
    */
    readonly regexPattern?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas postgresql_schemas}
*/
export declare class DataPostgresqlSchemas extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "postgresql_schemas";
    /**
    * Generates CDKTN code for importing a DataPostgresqlSchemas resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPostgresqlSchemas to import
    * @param importFromId The id of the existing DataPostgresqlSchemas that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPostgresqlSchemas to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/data-sources/schemas postgresql_schemas} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPostgresqlSchemasConfig
    */
    constructor(scope: Construct, id: string, config: DataPostgresqlSchemasConfig);
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeSystemSchemas?;
    get includeSystemSchemas(): boolean | cdktn.IResolvable;
    set includeSystemSchemas(value: boolean | cdktn.IResolvable);
    resetIncludeSystemSchemas(): void;
    get includeSystemSchemasInput(): boolean | cdktn.IResolvable | undefined;
    private _likeAllPatterns?;
    get likeAllPatterns(): string[];
    set likeAllPatterns(value: string[]);
    resetLikeAllPatterns(): void;
    get likeAllPatternsInput(): string[] | undefined;
    private _likeAnyPatterns?;
    get likeAnyPatterns(): string[];
    set likeAnyPatterns(value: string[]);
    resetLikeAnyPatterns(): void;
    get likeAnyPatternsInput(): string[] | undefined;
    private _notLikeAllPatterns?;
    get notLikeAllPatterns(): string[];
    set notLikeAllPatterns(value: string[]);
    resetNotLikeAllPatterns(): void;
    get notLikeAllPatternsInput(): string[] | undefined;
    private _regexPattern?;
    get regexPattern(): string;
    set regexPattern(value: string);
    resetRegexPattern(): void;
    get regexPatternInput(): string | undefined;
    get schemas(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
