/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ExtensionConfig extends cdktn.TerraformMetaArguments {
    /**
    * When true, will also create any extensions that this extension depends on that are not already installed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension#create_cascade Extension#create_cascade}
    */
    readonly createCascade?: boolean | cdktn.IResolvable;
    /**
    * Sets the database to add the extension to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension#database Extension#database}
    */
    readonly database?: string;
    /**
    * When true, will also drop all the objects that depend on the extension, and in turn all objects that depend on those objects
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension#drop_cascade Extension#drop_cascade}
    */
    readonly dropCascade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension#id Extension#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension#name Extension#name}
    */
    readonly name: string;
    /**
    * Sets the schema of an extension
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension#schema Extension#schema}
    */
    readonly schema?: string;
    /**
    * Sets the version number of the extension
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension#version Extension#version}
    */
    readonly version?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension postgresql_extension}
*/
export declare class Extension extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_extension";
    /**
    * Generates CDKTN code for importing a Extension resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Extension to import
    * @param importFromId The id of the existing Extension that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Extension to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/extension postgresql_extension} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ExtensionConfig
    */
    constructor(scope: Construct, id: string, config: ExtensionConfig);
    private _createCascade?;
    get createCascade(): boolean | cdktn.IResolvable;
    set createCascade(value: boolean | cdktn.IResolvable);
    resetCreateCascade(): void;
    get createCascadeInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _dropCascade?;
    get dropCascade(): boolean | cdktn.IResolvable;
    set dropCascade(value: boolean | cdktn.IResolvable);
    resetDropCascade(): void;
    get dropCascadeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
