/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Automatically drop objects that depend on the server (such as user mappings), and in turn all objects that depend on those objects. Drop RESTRICT is the default
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#drop_cascade Server#drop_cascade}
    */
    readonly dropCascade?: boolean | cdktn.IResolvable;
    /**
    * The name of the foreign-data wrapper that manages the server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#fdw_name Server#fdw_name}
    */
    readonly fdwName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#id Server#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * This clause specifies the options for the server. The options typically define the connection details of the server, but the actual names and values are dependent on the server's foreign-data wrapper
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#options Server#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * The name of the foreign server to be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#server_name Server#server_name}
    */
    readonly serverName: string;
    /**
    * The user name of the new owner of the foreign server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#server_owner Server#server_owner}
    */
    readonly serverOwner?: string;
    /**
    * Optional server type, potentially useful to foreign-data wrappers
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#server_type Server#server_type}
    */
    readonly serverType?: string;
    /**
    * Optional server version, potentially useful to foreign-data wrappers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#server_version Server#server_version}
    */
    readonly serverVersion?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server postgresql_server}
*/
export declare class Server extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_server";
    /**
    * Generates CDKTN code for importing a Server resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Server to import
    * @param importFromId The id of the existing Server that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Server to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/server postgresql_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerConfig
    */
    constructor(scope: Construct, id: string, config: ServerConfig);
    private _dropCascade?;
    get dropCascade(): boolean | cdktn.IResolvable;
    set dropCascade(value: boolean | cdktn.IResolvable);
    resetDropCascade(): void;
    get dropCascadeInput(): boolean | cdktn.IResolvable | undefined;
    private _fdwName?;
    get fdwName(): string;
    set fdwName(value: string);
    get fdwNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _serverName?;
    get serverName(): string;
    set serverName(value: string);
    get serverNameInput(): string | undefined;
    private _serverOwner?;
    get serverOwner(): string;
    set serverOwner(value: string);
    resetServerOwner(): void;
    get serverOwnerInput(): string | undefined;
    private _serverType?;
    get serverType(): string;
    set serverType(value: string);
    resetServerType(): void;
    get serverTypeInput(): string | undefined;
    private _serverVersion?;
    get serverVersion(): string;
    set serverVersion(value: string);
    resetServerVersion(): void;
    get serverVersionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
