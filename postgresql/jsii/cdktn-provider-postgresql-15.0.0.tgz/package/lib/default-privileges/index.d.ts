/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DefaultPrivilegesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The database to grant default privileges for this role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#database DefaultPrivileges#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#id DefaultPrivileges#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The PostgreSQL object type to set the default privileges on (one of: table, sequence, function, routine, type, schema)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#object_type DefaultPrivileges#object_type}
    */
    readonly objectType: string;
    /**
    * Target role for which to alter default privileges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#owner DefaultPrivileges#owner}
    */
    readonly owner: string;
    /**
    * The list of privileges to apply as default privileges
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#privileges DefaultPrivileges#privileges}
    */
    readonly privileges: string[];
    /**
    * The name of the role to which grant default privileges on
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#role DefaultPrivileges#role}
    */
    readonly role: string;
    /**
    * The database schema to set default privileges for this role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#schema DefaultPrivileges#schema}
    */
    readonly schema?: string;
    /**
    * Permit the grant recipient to grant it to others
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#with_grant_option DefaultPrivileges#with_grant_option}
    */
    readonly withGrantOption?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges postgresql_default_privileges}
*/
export declare class DefaultPrivileges extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_default_privileges";
    /**
    * Generates CDKTN code for importing a DefaultPrivileges resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DefaultPrivileges to import
    * @param importFromId The id of the existing DefaultPrivileges that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DefaultPrivileges to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/default_privileges postgresql_default_privileges} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DefaultPrivilegesConfig
    */
    constructor(scope: Construct, id: string, config: DefaultPrivilegesConfig);
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    get ownerInput(): string | undefined;
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    get privilegesInput(): string[] | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _withGrantOption?;
    get withGrantOption(): boolean | cdktn.IResolvable;
    set withGrantOption(value: boolean | cdktn.IResolvable);
    resetWithGrantOption(): void;
    get withGrantOptionInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
