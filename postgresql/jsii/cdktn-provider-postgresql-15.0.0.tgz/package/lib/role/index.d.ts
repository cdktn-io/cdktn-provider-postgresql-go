/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Role to switch to at login
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#assume_role Role#assume_role}
    */
    readonly assumeRole?: string;
    /**
    * Determine whether a role bypasses every row-level security (RLS) policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#bypass_row_level_security Role#bypass_row_level_security}
    */
    readonly bypassRowLevelSecurity?: boolean | cdktn.IResolvable;
    /**
    * How many concurrent connections can be made with this role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#connection_limit Role#connection_limit}
    */
    readonly connectionLimit?: number;
    /**
    * Define a role's ability to create databases
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#create_database Role#create_database}
    */
    readonly createDatabase?: boolean | cdktn.IResolvable;
    /**
    * Determine whether this role will be permitted to create new roles
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#create_role Role#create_role}
    */
    readonly createRole?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#encrypted Role#encrypted}
    */
    readonly encrypted?: string;
    /**
    * Control whether the password is stored encrypted in the system catalogs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#encrypted_password Role#encrypted_password}
    */
    readonly encryptedPassword?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#id Role#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Terminate any session with an open transaction that has been idle for longer than the specified duration in milliseconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#idle_in_transaction_session_timeout Role#idle_in_transaction_session_timeout}
    */
    readonly idleInTransactionSessionTimeout?: number;
    /**
    * Determine whether a role "inherits" the privileges of roles it is a member of
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#inherit Role#inherit}
    */
    readonly inherit?: boolean | cdktn.IResolvable;
    /**
    * Determine whether a role is allowed to log in
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#login Role#login}
    */
    readonly login?: boolean | cdktn.IResolvable;
    /**
    * The name of the role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#name Role#name}
    */
    readonly name: string;
    /**
    * Sets the role's password
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#password Role#password}
    */
    readonly password?: string;
    /**
    * Sets the role's password without storing it in the state file.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#password_wo Role#password_wo}
    */
    readonly passwordWo?: string;
    /**
    * Prevents applies from updating the role password on every apply unless the value changes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#password_wo_version Role#password_wo_version}
    */
    readonly passwordWoVersion?: string;
    /**
    * Determine whether a role is allowed to initiate streaming replication or put the system in and out of backup mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#replication Role#replication}
    */
    readonly replication?: boolean | cdktn.IResolvable;
    /**
    * Role(s) to grant to this new role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#roles Role#roles}
    */
    readonly roles?: string[];
    /**
    * Sets the role's search path
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#search_path Role#search_path}
    */
    readonly searchPath?: string[];
    /**
    * Skip actually running the DROP ROLE command when removing a ROLE from PostgreSQL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#skip_drop_role Role#skip_drop_role}
    */
    readonly skipDropRole?: boolean | cdktn.IResolvable;
    /**
    * Skip actually running the REASSIGN OWNED command when removing a role from PostgreSQL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#skip_reassign_owned Role#skip_reassign_owned}
    */
    readonly skipReassignOwned?: boolean | cdktn.IResolvable;
    /**
    * Abort any statement that takes more than the specified number of milliseconds
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#statement_timeout Role#statement_timeout}
    */
    readonly statementTimeout?: number;
    /**
    * Determine whether the new role is a "superuser"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#superuser Role#superuser}
    */
    readonly superuser?: boolean | cdktn.IResolvable;
    /**
    * Sets a date and time after which the role's password is no longer valid
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#valid_until Role#valid_until}
    */
    readonly validUntil?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role postgresql_role}
*/
export declare class Role extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_role";
    /**
    * Generates CDKTN code for importing a Role resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Role to import
    * @param importFromId The id of the existing Role that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Role to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/role postgresql_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RoleConfig
    */
    constructor(scope: Construct, id: string, config: RoleConfig);
    private _assumeRole?;
    get assumeRole(): string;
    set assumeRole(value: string);
    resetAssumeRole(): void;
    get assumeRoleInput(): string | undefined;
    private _bypassRowLevelSecurity?;
    get bypassRowLevelSecurity(): boolean | cdktn.IResolvable;
    set bypassRowLevelSecurity(value: boolean | cdktn.IResolvable);
    resetBypassRowLevelSecurity(): void;
    get bypassRowLevelSecurityInput(): boolean | cdktn.IResolvable | undefined;
    private _connectionLimit?;
    get connectionLimit(): number;
    set connectionLimit(value: number);
    resetConnectionLimit(): void;
    get connectionLimitInput(): number | undefined;
    private _createDatabase?;
    get createDatabase(): boolean | cdktn.IResolvable;
    set createDatabase(value: boolean | cdktn.IResolvable);
    resetCreateDatabase(): void;
    get createDatabaseInput(): boolean | cdktn.IResolvable | undefined;
    private _createRole?;
    get createRole(): boolean | cdktn.IResolvable;
    set createRole(value: boolean | cdktn.IResolvable);
    resetCreateRole(): void;
    get createRoleInput(): boolean | cdktn.IResolvable | undefined;
    private _encrypted?;
    get encrypted(): string;
    set encrypted(value: string);
    resetEncrypted(): void;
    get encryptedInput(): string | undefined;
    private _encryptedPassword?;
    get encryptedPassword(): boolean | cdktn.IResolvable;
    set encryptedPassword(value: boolean | cdktn.IResolvable);
    resetEncryptedPassword(): void;
    get encryptedPasswordInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleInTransactionSessionTimeout?;
    get idleInTransactionSessionTimeout(): number;
    set idleInTransactionSessionTimeout(value: number);
    resetIdleInTransactionSessionTimeout(): void;
    get idleInTransactionSessionTimeoutInput(): number | undefined;
    private _inherit?;
    get inherit(): boolean | cdktn.IResolvable;
    set inherit(value: boolean | cdktn.IResolvable);
    resetInherit(): void;
    get inheritInput(): boolean | cdktn.IResolvable | undefined;
    private _login?;
    get login(): boolean | cdktn.IResolvable;
    set login(value: boolean | cdktn.IResolvable);
    resetLogin(): void;
    get loginInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get passwordWo(): string;
    set passwordWo(value: string);
    resetPasswordWo(): void;
    get passwordWoInput(): string | undefined;
    private _passwordWoVersion?;
    get passwordWoVersion(): string;
    set passwordWoVersion(value: string);
    resetPasswordWoVersion(): void;
    get passwordWoVersionInput(): string | undefined;
    private _replication?;
    get replication(): boolean | cdktn.IResolvable;
    set replication(value: boolean | cdktn.IResolvable);
    resetReplication(): void;
    get replicationInput(): boolean | cdktn.IResolvable | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _searchPath?;
    get searchPath(): string[];
    set searchPath(value: string[]);
    resetSearchPath(): void;
    get searchPathInput(): string[] | undefined;
    private _skipDropRole?;
    get skipDropRole(): boolean | cdktn.IResolvable;
    set skipDropRole(value: boolean | cdktn.IResolvable);
    resetSkipDropRole(): void;
    get skipDropRoleInput(): boolean | cdktn.IResolvable | undefined;
    private _skipReassignOwned?;
    get skipReassignOwned(): boolean | cdktn.IResolvable;
    set skipReassignOwned(value: boolean | cdktn.IResolvable);
    resetSkipReassignOwned(): void;
    get skipReassignOwnedInput(): boolean | cdktn.IResolvable | undefined;
    private _statementTimeout?;
    get statementTimeout(): number;
    set statementTimeout(value: number);
    resetStatementTimeout(): void;
    get statementTimeoutInput(): number | undefined;
    private _superuser?;
    get superuser(): boolean | cdktn.IResolvable;
    set superuser(value: boolean | cdktn.IResolvable);
    resetSuperuser(): void;
    get superuserInput(): boolean | cdktn.IResolvable | undefined;
    private _validUntil?;
    get validUntil(): string;
    set validUntil(value: string);
    resetValidUntil(): void;
    get validUntilInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
