/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
export * as database from './database/index';
export * as defaultPrivileges from './default-privileges/index';
export * as extension from './extension/index';
export * as functionResource from './function-resource/index';
export * as grant from './grant/index';
export * as grantRole from './grant-role/index';
export * as physicalReplicationSlot from './physical-replication-slot/index';
export * as publication from './publication/index';
export * as replicationSlot from './replication-slot/index';
export * as role from './role/index';
export * as schema from './schema/index';
export * as securityLabel from './security-label/index';
export * as server from './server/index';
export * as subscription from './subscription/index';
export * as userMapping from './user-mapping/index';
export * as dataPostgresqlSchemas from './data-postgresql-schemas/index';
export * as dataPostgresqlSequences from './data-postgresql-sequences/index';
export * as dataPostgresqlTables from './data-postgresql-tables/index';
export * as provider from './provider/index';
