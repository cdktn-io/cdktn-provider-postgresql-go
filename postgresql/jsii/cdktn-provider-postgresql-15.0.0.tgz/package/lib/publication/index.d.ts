/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PublicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Sets the tables list to publish to ALL tables
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#all_tables Publication#all_tables}
    */
    readonly allTables?: boolean | cdktn.IResolvable;
    /**
    * Sets the database to add the publication for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#database Publication#database}
    */
    readonly database?: string;
    /**
    * When true, will also drop all the objects that depend on the publication, and in turn all objects that depend on those objects
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#drop_cascade Publication#drop_cascade}
    */
    readonly dropCascade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#id Publication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#name Publication#name}
    */
    readonly name: string;
    /**
    * Sets the owner of the publication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#owner Publication#owner}
    */
    readonly owner?: string;
    /**
    * Sets which DML operations will be published
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#publish_param Publication#publish_param}
    */
    readonly publishParam?: string[];
    /**
    * Sets whether changes in a partitioned table using the identity and schema of the partitioned table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#publish_via_partition_root_param Publication#publish_via_partition_root_param}
    */
    readonly publishViaPartitionRootParam?: boolean | cdktn.IResolvable;
    /**
    * Sets the tables list to publish
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#tables Publication#tables}
    */
    readonly tables?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication postgresql_publication}
*/
export declare class Publication extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_publication";
    /**
    * Generates CDKTN code for importing a Publication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Publication to import
    * @param importFromId The id of the existing Publication that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Publication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/publication postgresql_publication} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PublicationConfig
    */
    constructor(scope: Construct, id: string, config: PublicationConfig);
    private _allTables?;
    get allTables(): boolean | cdktn.IResolvable;
    set allTables(value: boolean | cdktn.IResolvable);
    resetAllTables(): void;
    get allTablesInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _dropCascade?;
    get dropCascade(): boolean | cdktn.IResolvable;
    set dropCascade(value: boolean | cdktn.IResolvable);
    resetDropCascade(): void;
    get dropCascadeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _publishParam?;
    get publishParam(): string[];
    set publishParam(value: string[]);
    resetPublishParam(): void;
    get publishParamInput(): string[] | undefined;
    private _publishViaPartitionRootParam?;
    get publishViaPartitionRootParam(): boolean | cdktn.IResolvable;
    set publishViaPartitionRootParam(value: boolean | cdktn.IResolvable);
    resetPublishViaPartitionRootParam(): void;
    get publishViaPartitionRootParamInput(): boolean | cdktn.IResolvable | undefined;
    private _tables?;
    get tables(): string[];
    set tables(value: string[]);
    resetTables(): void;
    get tablesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
