/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FunctionResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Body of the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#body FunctionResource#body}
    */
    readonly body: string;
    /**
    * The database where the function is located. If not specified, the provider default database is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#database FunctionResource#database}
    */
    readonly database?: string;
    /**
    * Automatically drop objects that depend on the function (such as operators or triggers), and in turn all objects that depend on those objects.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#drop_cascade FunctionResource#drop_cascade}
    */
    readonly dropCascade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#id FunctionResource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Language of the function. One of: internal, sql, c, plpgsql
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#language FunctionResource#language}
    */
    readonly language?: string;
    /**
    * Name of the function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#name FunctionResource#name}
    */
    readonly name: string;
    /**
    * If the function can be executed in parallel for a single query execution. One of: UNSAFE, RESTRICTED, SAFE
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#parallel FunctionResource#parallel}
    */
    readonly parallel?: string;
    /**
    * Function return type. If not specified, it will be calculated based on the output arguments
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#returns FunctionResource#returns}
    */
    readonly returns?: string;
    /**
    * Schema where the function is located. If not specified, the provider default schema is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#schema FunctionResource#schema}
    */
    readonly schema?: string;
    /**
    * If the function should execute with the permissions of the function owner instead of the permissions of the caller.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#security_definer FunctionResource#security_definer}
    */
    readonly securityDefiner?: boolean | cdktn.IResolvable;
    /**
    * If the function should always return NULL if any of it's inputs is NULL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#strict FunctionResource#strict}
    */
    readonly strict?: boolean | cdktn.IResolvable;
    /**
    * Volatility of the function. One of: VOLATILE, STABLE, IMMUTABLE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#volatility FunctionResource#volatility}
    */
    readonly volatility?: string;
    /**
    * arg block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#arg FunctionResource#arg}
    */
    readonly arg?: FunctionResourceArg[] | cdktn.IResolvable;
}
export interface FunctionResourceArg {
    /**
    * An expression to be used as default value if the parameter is not specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#default FunctionResource#default}
    */
    readonly default?: string;
    /**
    * The argument mode. One of: IN, OUT, INOUT, or VARIADIC
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#mode FunctionResource#mode}
    */
    readonly mode?: string;
    /**
    * The argument name. The name may be required for some languages or depending on the argument mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#name FunctionResource#name}
    */
    readonly name?: string;
    /**
    * The argument type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#type FunctionResource#type}
    */
    readonly type: string;
}
export declare function functionResourceArgToTerraform(struct?: FunctionResourceArg | cdktn.IResolvable): any;
export declare function functionResourceArgToHclTerraform(struct?: FunctionResourceArg | cdktn.IResolvable): any;
export declare class FunctionResourceArgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FunctionResourceArg | cdktn.IResolvable | undefined;
    set internalValue(value: FunctionResourceArg | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class FunctionResourceArgList extends cdktn.ComplexList {
    internalValue?: FunctionResourceArg[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FunctionResourceArgOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function postgresql_function}
*/
export declare class FunctionResource extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_function";
    /**
    * Generates CDKTN code for importing a FunctionResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FunctionResource to import
    * @param importFromId The id of the existing FunctionResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FunctionResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/function postgresql_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FunctionResourceConfig
    */
    constructor(scope: Construct, id: string, config: FunctionResourceConfig);
    private _body?;
    get body(): string;
    set body(value: string);
    get bodyInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _dropCascade?;
    get dropCascade(): boolean | cdktn.IResolvable;
    set dropCascade(value: boolean | cdktn.IResolvable);
    resetDropCascade(): void;
    get dropCascadeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _language?;
    get language(): string;
    set language(value: string);
    resetLanguage(): void;
    get languageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parallel?;
    get parallel(): string;
    set parallel(value: string);
    resetParallel(): void;
    get parallelInput(): string | undefined;
    private _returns?;
    get returns(): string;
    set returns(value: string);
    resetReturns(): void;
    get returnsInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _securityDefiner?;
    get securityDefiner(): boolean | cdktn.IResolvable;
    set securityDefiner(value: boolean | cdktn.IResolvable);
    resetSecurityDefiner(): void;
    get securityDefinerInput(): boolean | cdktn.IResolvable | undefined;
    private _strict?;
    get strict(): boolean | cdktn.IResolvable;
    set strict(value: boolean | cdktn.IResolvable);
    resetStrict(): void;
    get strictInput(): boolean | cdktn.IResolvable | undefined;
    private _volatility?;
    get volatility(): string;
    set volatility(value: string);
    resetVolatility(): void;
    get volatilityInput(): string | undefined;
    private _arg;
    get arg(): FunctionResourceArgList;
    putArg(value: FunctionResourceArg[] | cdktn.IResolvable): void;
    resetArg(): void;
    get argInput(): cdktn.IResolvable | FunctionResourceArg[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
