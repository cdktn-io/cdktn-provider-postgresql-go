/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * If false then no one can connect to this database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#allow_connections Database#allow_connections}
    */
    readonly allowConnections?: boolean | cdktn.IResolvable;
    /**
    * If true, the owner of already existing objects will change if the owner changes
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#alter_object_ownership Database#alter_object_ownership}
    */
    readonly alterObjectOwnership?: boolean | cdktn.IResolvable;
    /**
    * How many concurrent connections can be made to this database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#connection_limit Database#connection_limit}
    */
    readonly connectionLimit?: number;
    /**
    * Character set encoding to use in the new database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#encoding Database#encoding}
    */
    readonly encoding?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#id Database#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * If true, then this database can be cloned by any user with CREATEDB privileges
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#is_template Database#is_template}
    */
    readonly isTemplate?: boolean | cdktn.IResolvable;
    /**
    * Collation order (LC_COLLATE) to use in the new database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#lc_collate Database#lc_collate}
    */
    readonly lcCollate?: string;
    /**
    * Character classification (LC_CTYPE) to use in the new database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#lc_ctype Database#lc_ctype}
    */
    readonly lcCtype?: string;
    /**
    * The PostgreSQL database name to connect to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#name Database#name}
    */
    readonly name: string;
    /**
    * The ROLE which owns the database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#owner Database#owner}
    */
    readonly owner?: string;
    /**
    * The name of the tablespace that will be associated with the new database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#tablespace_name Database#tablespace_name}
    */
    readonly tablespaceName?: string;
    /**
    * The name of the template from which to create the new database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#template Database#template}
    */
    readonly template?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database postgresql_database}
*/
export declare class Database extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_database";
    /**
    * Generates CDKTN code for importing a Database resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Database to import
    * @param importFromId The id of the existing Database that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Database to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.27.0/docs/resources/database postgresql_database} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseConfig);
    private _allowConnections?;
    get allowConnections(): boolean | cdktn.IResolvable;
    set allowConnections(value: boolean | cdktn.IResolvable);
    resetAllowConnections(): void;
    get allowConnectionsInput(): boolean | cdktn.IResolvable | undefined;
    private _alterObjectOwnership?;
    get alterObjectOwnership(): boolean | cdktn.IResolvable;
    set alterObjectOwnership(value: boolean | cdktn.IResolvable);
    resetAlterObjectOwnership(): void;
    get alterObjectOwnershipInput(): boolean | cdktn.IResolvable | undefined;
    private _connectionLimit?;
    get connectionLimit(): number;
    set connectionLimit(value: number);
    resetConnectionLimit(): void;
    get connectionLimitInput(): number | undefined;
    private _encoding?;
    get encoding(): string;
    set encoding(value: string);
    resetEncoding(): void;
    get encodingInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isTemplate?;
    get isTemplate(): boolean | cdktn.IResolvable;
    set isTemplate(value: boolean | cdktn.IResolvable);
    resetIsTemplate(): void;
    get isTemplateInput(): boolean | cdktn.IResolvable | undefined;
    private _lcCollate?;
    get lcCollate(): string;
    set lcCollate(value: string);
    resetLcCollate(): void;
    get lcCollateInput(): string | undefined;
    private _lcCtype?;
    get lcCtype(): string;
    set lcCtype(value: string);
    resetLcCtype(): void;
    get lcCtypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _tablespaceName?;
    get tablespaceName(): string;
    set tablespaceName(value: string);
    resetTablespaceName(): void;
    get tablespaceNameInput(): string | undefined;
    private _template?;
    get template(): string;
    set template(value: string);
    resetTemplate(): void;
    get templateInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
