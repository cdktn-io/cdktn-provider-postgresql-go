/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The connection string to the publisher. It should follow the keyword/value format (https://www.postgresql.org/docs/current/libpq-connect.html#LIBPQ-CONNSTRING)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription#conninfo Subscription#conninfo}
    */
    readonly conninfo: string;
    /**
    * Specifies whether the command should create the replication slot on the publisher
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription#create_slot Subscription#create_slot}
    */
    readonly createSlot?: boolean | cdktn.IResolvable;
    /**
    * Sets the database to add the subscription for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription#database Subscription#database}
    */
    readonly database?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription#id Subscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the subscription
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription#name Subscription#name}
    */
    readonly name: string;
    /**
    * Names of the publications on the publisher to subscribe to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription#publications Subscription#publications}
    */
    readonly publications: string[];
    /**
    * Name of the replication slot to use. The default behavior is to use the name of the subscription for the slot name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription#slot_name Subscription#slot_name}
    */
    readonly slotName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription postgresql_subscription}
*/
export declare class Subscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_subscription";
    /**
    * Generates CDKTN code for importing a Subscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Subscription to import
    * @param importFromId The id of the existing Subscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Subscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/subscription postgresql_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: SubscriptionConfig);
    private _conninfo?;
    get conninfo(): string;
    set conninfo(value: string);
    get conninfoInput(): string | undefined;
    private _createSlot?;
    get createSlot(): boolean | cdktn.IResolvable;
    set createSlot(value: boolean | cdktn.IResolvable);
    resetCreateSlot(): void;
    get createSlotInput(): boolean | cdktn.IResolvable | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publications?;
    get publications(): string[];
    set publications(value: string[]);
    get publicationsInput(): string[] | undefined;
    private _slotName?;
    get slotName(): string;
    set slotName(value: string);
    resetSlotName(): void;
    get slotNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
