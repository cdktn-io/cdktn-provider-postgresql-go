/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPostgresqlTablesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The PostgreSQL database which will be queried for table names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#database DataPostgresqlTables#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#id DataPostgresqlTables#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Expression(s) which will be pattern matched against table names in the query using the PostgreSQL LIKE ALL operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#like_all_patterns DataPostgresqlTables#like_all_patterns}
    */
    readonly likeAllPatterns?: string[];
    /**
    * Expression(s) which will be pattern matched against table names in the query using the PostgreSQL LIKE ANY operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#like_any_patterns DataPostgresqlTables#like_any_patterns}
    */
    readonly likeAnyPatterns?: string[];
    /**
    * Expression(s) which will be pattern matched against table names in the query using the PostgreSQL NOT LIKE ALL operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#not_like_all_patterns DataPostgresqlTables#not_like_all_patterns}
    */
    readonly notLikeAllPatterns?: string[];
    /**
    * Expression which will be pattern matched against table names in the query using the PostgreSQL ~ (regular expression match) operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#regex_pattern DataPostgresqlTables#regex_pattern}
    */
    readonly regexPattern?: string;
    /**
    * The PostgreSQL schema(s) which will be queried for table names. Queries all schemas in the database by default
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#schemas DataPostgresqlTables#schemas}
    */
    readonly schemas?: string[];
    /**
    * The PostgreSQL table types which will be queried for table names. Includes all table types by default. Use 'BASE TABLE' for normal tables only
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#table_types DataPostgresqlTables#table_types}
    */
    readonly tableTypes?: string[];
}
export interface DataPostgresqlTablesTables {
}
export declare function dataPostgresqlTablesTablesToTerraform(struct?: DataPostgresqlTablesTables): any;
export declare function dataPostgresqlTablesTablesToHclTerraform(struct?: DataPostgresqlTablesTables): any;
export declare class DataPostgresqlTablesTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPostgresqlTablesTables | undefined;
    set internalValue(value: DataPostgresqlTablesTables | undefined);
    get objectName(): string;
    get schemaName(): string;
    get tableType(): string;
}
export declare class DataPostgresqlTablesTablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPostgresqlTablesTablesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables postgresql_tables}
*/
export declare class DataPostgresqlTables extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "postgresql_tables";
    /**
    * Generates CDKTN code for importing a DataPostgresqlTables resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPostgresqlTables to import
    * @param importFromId The id of the existing DataPostgresqlTables that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPostgresqlTables to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/tables postgresql_tables} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPostgresqlTablesConfig
    */
    constructor(scope: Construct, id: string, config: DataPostgresqlTablesConfig);
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _likeAllPatterns?;
    get likeAllPatterns(): string[];
    set likeAllPatterns(value: string[]);
    resetLikeAllPatterns(): void;
    get likeAllPatternsInput(): string[] | undefined;
    private _likeAnyPatterns?;
    get likeAnyPatterns(): string[];
    set likeAnyPatterns(value: string[]);
    resetLikeAnyPatterns(): void;
    get likeAnyPatternsInput(): string[] | undefined;
    private _notLikeAllPatterns?;
    get notLikeAllPatterns(): string[];
    set notLikeAllPatterns(value: string[]);
    resetNotLikeAllPatterns(): void;
    get notLikeAllPatternsInput(): string[] | undefined;
    private _regexPattern?;
    get regexPattern(): string;
    set regexPattern(value: string);
    resetRegexPattern(): void;
    get regexPatternInput(): string | undefined;
    private _schemas?;
    get schemas(): string[];
    set schemas(value: string[]);
    resetSchemas(): void;
    get schemasInput(): string[] | undefined;
    private _tableTypes?;
    get tableTypes(): string[];
    set tableTypes(value: string[]);
    resetTableTypes(): void;
    get tableTypesInput(): string[] | undefined;
    private _tables;
    get tables(): DataPostgresqlTablesTablesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
