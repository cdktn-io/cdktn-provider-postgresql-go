/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresqlProviderConfig {
    /**
    * Use rds_iam instead of password authentication (see: https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/UsingWithRDS.IAMDBAuth.html)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#aws_rds_iam_auth PostgresqlProvider#aws_rds_iam_auth}
    */
    readonly awsRdsIamAuth?: boolean | cdktn.IResolvable;
    /**
    * AWS profile to use for IAM auth
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#aws_rds_iam_profile PostgresqlProvider#aws_rds_iam_profile}
    */
    readonly awsRdsIamProfile?: string;
    /**
    * AWS IAM role to assume for IAM auth
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#aws_rds_iam_provider_role_arn PostgresqlProvider#aws_rds_iam_provider_role_arn}
    */
    readonly awsRdsIamProviderRoleArn?: string;
    /**
    * AWS region to use for IAM auth
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#aws_rds_iam_region PostgresqlProvider#aws_rds_iam_region}
    */
    readonly awsRdsIamRegion?: string;
    /**
    * Use MS Azure identity OAuth token (see: https://learn.microsoft.com/en-us/azure/postgresql/flexible-server/how-to-configure-sign-in-azure-ad-authentication)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#azure_identity_auth PostgresqlProvider#azure_identity_auth}
    */
    readonly azureIdentityAuth?: boolean | cdktn.IResolvable;
    /**
    * MS Azure tenant ID (see: https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config.html)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#azure_tenant_id PostgresqlProvider#azure_tenant_id}
    */
    readonly azureTenantId?: string;
    /**
    * Maximum wait for connection, in seconds. Zero or not specified means wait indefinitely.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#connect_timeout PostgresqlProvider#connect_timeout}
    */
    readonly connectTimeout?: number;
    /**
    * The name of the database to connect to in order to connect to (defaults to `postgres`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#database PostgresqlProvider#database}
    */
    readonly database?: string;
    /**
    * Database username associated to the connected user (for user name maps)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#database_username PostgresqlProvider#database_username}
    */
    readonly databaseUsername?: string;
    /**
    * Specify the expected version of PostgreSQL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#expected_version PostgresqlProvider#expected_version}
    */
    readonly expectedVersion?: string;
    /**
    * Service account to impersonate when using GCP IAM authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#gcp_iam_impersonate_service_account PostgresqlProvider#gcp_iam_impersonate_service_account}
    */
    readonly gcpIamImpersonateServiceAccount?: string;
    /**
    * Name of PostgreSQL server address to connect to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#host PostgresqlProvider#host}
    */
    readonly host?: string;
    /**
    * Maximum number of connections to establish to the database. Zero means unlimited.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#max_connections PostgresqlProvider#max_connections}
    */
    readonly maxConnections?: number;
    /**
    * Password to be used if the PostgreSQL server demands password authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#password PostgresqlProvider#password}
    */
    readonly password?: string;
    /**
    * The PostgreSQL port number to connect to at the server host, or socket file name extension for Unix-domain connections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#port PostgresqlProvider#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#scheme PostgresqlProvider#scheme}
    */
    readonly scheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#ssl_mode PostgresqlProvider#ssl_mode}
    */
    readonly sslMode?: string;
    /**
    * This option determines whether or with what priority a secure SSL TCP/IP connection will be negotiated with the PostgreSQL server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#sslmode PostgresqlProvider#sslmode}
    */
    readonly sslmode?: string;
    /**
    * The SSL server root certificate file path. The file must contain PEM encoded data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#sslrootcert PostgresqlProvider#sslrootcert}
    */
    readonly sslrootcert?: string;
    /**
    * Specify if the user to connect as is a Postgres superuser or not.If not, some feature might be disabled (e.g.: Refreshing state password from Postgres)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#superuser PostgresqlProvider#superuser}
    */
    readonly superuser?: boolean | cdktn.IResolvable;
    /**
    * PostgreSQL user name to connect as
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#username PostgresqlProvider#username}
    */
    readonly username?: string;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#alias PostgresqlProvider#alias}
    */
    readonly alias?: string;
    /**
    * clientcert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#clientcert PostgresqlProvider#clientcert}
    */
    readonly clientcert?: PostgresqlProviderClientcert;
}
export interface PostgresqlProviderClientcert {
    /**
    * The SSL client certificate file path. The file must contain PEM encoded data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#cert PostgresqlProvider#cert}
    */
    readonly cert: string;
    /**
    * The SSL client certificate private key file path. The file must contain PEM encoded data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#key PostgresqlProvider#key}
    */
    readonly key: string;
    /**
    * Must be set to true if you are inlining the cert/key instead of using a file path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#sslinline PostgresqlProvider#sslinline}
    */
    readonly sslinline?: boolean | cdktn.IResolvable;
}
export declare function postgresqlProviderClientcertToTerraform(struct?: PostgresqlProviderClientcert): any;
export declare function postgresqlProviderClientcertToHclTerraform(struct?: PostgresqlProviderClientcert): any;
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs postgresql}
*/
export declare class PostgresqlProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "postgresql";
    /**
    * Generates CDKTN code for importing a PostgresqlProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresqlProvider to import
    * @param importFromId The id of the existing PostgresqlProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresqlProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs postgresql} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresqlProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: PostgresqlProviderConfig);
    private _awsRdsIamAuth?;
    get awsRdsIamAuth(): boolean | cdktn.IResolvable | undefined;
    set awsRdsIamAuth(value: boolean | cdktn.IResolvable | undefined);
    resetAwsRdsIamAuth(): void;
    get awsRdsIamAuthInput(): boolean | cdktn.IResolvable | undefined;
    private _awsRdsIamProfile?;
    get awsRdsIamProfile(): string | undefined;
    set awsRdsIamProfile(value: string | undefined);
    resetAwsRdsIamProfile(): void;
    get awsRdsIamProfileInput(): string | undefined;
    private _awsRdsIamProviderRoleArn?;
    get awsRdsIamProviderRoleArn(): string | undefined;
    set awsRdsIamProviderRoleArn(value: string | undefined);
    resetAwsRdsIamProviderRoleArn(): void;
    get awsRdsIamProviderRoleArnInput(): string | undefined;
    private _awsRdsIamRegion?;
    get awsRdsIamRegion(): string | undefined;
    set awsRdsIamRegion(value: string | undefined);
    resetAwsRdsIamRegion(): void;
    get awsRdsIamRegionInput(): string | undefined;
    private _azureIdentityAuth?;
    get azureIdentityAuth(): boolean | cdktn.IResolvable | undefined;
    set azureIdentityAuth(value: boolean | cdktn.IResolvable | undefined);
    resetAzureIdentityAuth(): void;
    get azureIdentityAuthInput(): boolean | cdktn.IResolvable | undefined;
    private _azureTenantId?;
    get azureTenantId(): string | undefined;
    set azureTenantId(value: string | undefined);
    resetAzureTenantId(): void;
    get azureTenantIdInput(): string | undefined;
    private _connectTimeout?;
    get connectTimeout(): number | undefined;
    set connectTimeout(value: number | undefined);
    resetConnectTimeout(): void;
    get connectTimeoutInput(): number | undefined;
    private _database?;
    get database(): string | undefined;
    set database(value: string | undefined);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _databaseUsername?;
    get databaseUsername(): string | undefined;
    set databaseUsername(value: string | undefined);
    resetDatabaseUsername(): void;
    get databaseUsernameInput(): string | undefined;
    private _expectedVersion?;
    get expectedVersion(): string | undefined;
    set expectedVersion(value: string | undefined);
    resetExpectedVersion(): void;
    get expectedVersionInput(): string | undefined;
    private _gcpIamImpersonateServiceAccount?;
    get gcpIamImpersonateServiceAccount(): string | undefined;
    set gcpIamImpersonateServiceAccount(value: string | undefined);
    resetGcpIamImpersonateServiceAccount(): void;
    get gcpIamImpersonateServiceAccountInput(): string | undefined;
    private _host?;
    get host(): string | undefined;
    set host(value: string | undefined);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _maxConnections?;
    get maxConnections(): number | undefined;
    set maxConnections(value: number | undefined);
    resetMaxConnections(): void;
    get maxConnectionsInput(): number | undefined;
    private _password?;
    get password(): string | undefined;
    set password(value: string | undefined);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number | undefined;
    set port(value: number | undefined);
    resetPort(): void;
    get portInput(): number | undefined;
    private _scheme?;
    get scheme(): string | undefined;
    set scheme(value: string | undefined);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _sslMode?;
    get sslMode(): string | undefined;
    set sslMode(value: string | undefined);
    resetSslMode(): void;
    get sslModeInput(): string | undefined;
    private _sslmode?;
    get sslmode(): string | undefined;
    set sslmode(value: string | undefined);
    resetSslmode(): void;
    get sslmodeInput(): string | undefined;
    private _sslrootcert?;
    get sslrootcert(): string | undefined;
    set sslrootcert(value: string | undefined);
    resetSslrootcert(): void;
    get sslrootcertInput(): string | undefined;
    private _superuser?;
    get superuser(): boolean | cdktn.IResolvable | undefined;
    set superuser(value: boolean | cdktn.IResolvable | undefined);
    resetSuperuser(): void;
    get superuserInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string | undefined;
    set username(value: string | undefined);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _clientcert?;
    get clientcert(): PostgresqlProviderClientcert | undefined;
    set clientcert(value: PostgresqlProviderClientcert | undefined);
    resetClientcert(): void;
    get clientcertInput(): PostgresqlProviderClientcert | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
