/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataPostgresqlSequencesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The PostgreSQL database which will be queried for sequence names
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences#database DataPostgresqlSequences#database}
    */
    readonly database: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences#id DataPostgresqlSequences#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Expression(s) which will be pattern matched against sequence names in the query using the PostgreSQL LIKE ALL operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences#like_all_patterns DataPostgresqlSequences#like_all_patterns}
    */
    readonly likeAllPatterns?: string[];
    /**
    * Expression(s) which will be pattern matched against sequence names in the query using the PostgreSQL LIKE ANY operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences#like_any_patterns DataPostgresqlSequences#like_any_patterns}
    */
    readonly likeAnyPatterns?: string[];
    /**
    * Expression(s) which will be pattern matched against sequence names in the query using the PostgreSQL NOT LIKE ALL operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences#not_like_all_patterns DataPostgresqlSequences#not_like_all_patterns}
    */
    readonly notLikeAllPatterns?: string[];
    /**
    * Expression which will be pattern matched against sequence names in the query using the PostgreSQL ~ (regular expression match) operator
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences#regex_pattern DataPostgresqlSequences#regex_pattern}
    */
    readonly regexPattern?: string;
    /**
    * The PostgreSQL schema(s) which will be queried for sequence names. Queries all schemas in the database by default
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences#schemas DataPostgresqlSequences#schemas}
    */
    readonly schemas?: string[];
}
export interface DataPostgresqlSequencesSequences {
}
export declare function dataPostgresqlSequencesSequencesToTerraform(struct?: DataPostgresqlSequencesSequences): any;
export declare function dataPostgresqlSequencesSequencesToHclTerraform(struct?: DataPostgresqlSequencesSequences): any;
export declare class DataPostgresqlSequencesSequencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataPostgresqlSequencesSequences | undefined;
    set internalValue(value: DataPostgresqlSequencesSequences | undefined);
    get dataType(): string;
    get objectName(): string;
    get schemaName(): string;
}
export declare class DataPostgresqlSequencesSequencesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataPostgresqlSequencesSequencesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences postgresql_sequences}
*/
export declare class DataPostgresqlSequences extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "postgresql_sequences";
    /**
    * Generates CDKTN code for importing a DataPostgresqlSequences resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataPostgresqlSequences to import
    * @param importFromId The id of the existing DataPostgresqlSequences that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataPostgresqlSequences to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/data-sources/sequences postgresql_sequences} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataPostgresqlSequencesConfig
    */
    constructor(scope: Construct, id: string, config: DataPostgresqlSequencesConfig);
    private _database?;
    get database(): string;
    set database(value: string);
    get databaseInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _likeAllPatterns?;
    get likeAllPatterns(): string[];
    set likeAllPatterns(value: string[]);
    resetLikeAllPatterns(): void;
    get likeAllPatternsInput(): string[] | undefined;
    private _likeAnyPatterns?;
    get likeAnyPatterns(): string[];
    set likeAnyPatterns(value: string[]);
    resetLikeAnyPatterns(): void;
    get likeAnyPatternsInput(): string[] | undefined;
    private _notLikeAllPatterns?;
    get notLikeAllPatterns(): string[];
    set notLikeAllPatterns(value: string[]);
    resetNotLikeAllPatterns(): void;
    get notLikeAllPatternsInput(): string[] | undefined;
    private _regexPattern?;
    get regexPattern(): string;
    set regexPattern(value: string);
    resetRegexPattern(): void;
    get regexPatternInput(): string | undefined;
    private _schemas?;
    get schemas(): string[];
    set schemas(value: string[]);
    resetSchemas(): void;
    get schemasInput(): string[] | undefined;
    private _sequences;
    get sequences(): DataPostgresqlSequencesSequencesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
