/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SchemaConfig extends cdktn.TerraformMetaArguments {
    /**
    * The database name to alter schema
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#database Schema#database}
    */
    readonly database?: string;
    /**
    * When true, will also drop all the objects that are contained in the schema
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#drop_cascade Schema#drop_cascade}
    */
    readonly dropCascade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#id Schema#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * When true, use the existing schema if it exists
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#if_not_exists Schema#if_not_exists}
    */
    readonly ifNotExists?: boolean | cdktn.IResolvable;
    /**
    * The name of the schema
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#name Schema#name}
    */
    readonly name: string;
    /**
    * The ROLE name who owns the schema
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#owner Schema#owner}
    */
    readonly owner?: string;
    /**
    * policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#policy Schema#policy}
    */
    readonly policy?: SchemaPolicy[] | cdktn.IResolvable;
}
export interface SchemaPolicy {
    /**
    * If true, allow the specified ROLEs to CREATE new objects within the schema(s)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#create Schema#create}
    */
    readonly create?: boolean | cdktn.IResolvable;
    /**
    * If true, allow the specified ROLEs to CREATE new objects within the schema(s) and GRANT the same CREATE privilege to different ROLEs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#create_with_grant Schema#create_with_grant}
    */
    readonly createWithGrant?: boolean | cdktn.IResolvable;
    /**
    * ROLE who will receive this policy (default: PUBLIC)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#role Schema#role}
    */
    readonly role?: string;
    /**
    * If true, allow the specified ROLEs to use objects within the schema(s)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#usage Schema#usage}
    */
    readonly usage?: boolean | cdktn.IResolvable;
    /**
    * If true, allow the specified ROLEs to use objects within the schema(s) and GRANT the same USAGE privilege to different ROLEs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#usage_with_grant Schema#usage_with_grant}
    */
    readonly usageWithGrant?: boolean | cdktn.IResolvable;
}
export declare function schemaPolicyToTerraform(struct?: SchemaPolicy | cdktn.IResolvable): any;
export declare function schemaPolicyToHclTerraform(struct?: SchemaPolicy | cdktn.IResolvable): any;
export declare class SchemaPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SchemaPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: SchemaPolicy | cdktn.IResolvable | undefined);
    private _create?;
    get create(): boolean | cdktn.IResolvable;
    set create(value: boolean | cdktn.IResolvable);
    resetCreate(): void;
    get createInput(): boolean | cdktn.IResolvable | undefined;
    private _createWithGrant?;
    get createWithGrant(): boolean | cdktn.IResolvable;
    set createWithGrant(value: boolean | cdktn.IResolvable);
    resetCreateWithGrant(): void;
    get createWithGrantInput(): boolean | cdktn.IResolvable | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _usage?;
    get usage(): boolean | cdktn.IResolvable;
    set usage(value: boolean | cdktn.IResolvable);
    resetUsage(): void;
    get usageInput(): boolean | cdktn.IResolvable | undefined;
    private _usageWithGrant?;
    get usageWithGrant(): boolean | cdktn.IResolvable;
    set usageWithGrant(value: boolean | cdktn.IResolvable);
    resetUsageWithGrant(): void;
    get usageWithGrantInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class SchemaPolicyList extends cdktn.ComplexList {
    internalValue?: SchemaPolicy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SchemaPolicyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema postgresql_schema}
*/
export declare class Schema extends cdktn.TerraformResource {
    static readonly tfResourceType = "postgresql_schema";
    /**
    * Generates CDKTN code for importing a Schema resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Schema to import
    * @param importFromId The id of the existing Schema that should be imported. Refer to the {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Schema to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cyrilgdn/postgresql/1.26.0/docs/resources/schema postgresql_schema} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SchemaConfig
    */
    constructor(scope: Construct, id: string, config: SchemaConfig);
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _dropCascade?;
    get dropCascade(): boolean | cdktn.IResolvable;
    set dropCascade(value: boolean | cdktn.IResolvable);
    resetDropCascade(): void;
    get dropCascadeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ifNotExists?;
    get ifNotExists(): boolean | cdktn.IResolvable;
    set ifNotExists(value: boolean | cdktn.IResolvable);
    resetIfNotExists(): void;
    get ifNotExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _policy;
    get policy(): SchemaPolicyList;
    putPolicy(value: SchemaPolicy[] | cdktn.IResolvable): void;
    resetPolicy(): void;
    get policyInput(): cdktn.IResolvable | SchemaPolicy[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
