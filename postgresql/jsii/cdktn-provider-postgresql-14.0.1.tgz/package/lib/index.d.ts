/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
export * as database from './database';
export * as defaultPrivileges from './default-privileges';
export * as extension from './extension';
export * as functionResource from './function-resource';
export * as grant from './grant';
export * as grantRole from './grant-role';
export * as physicalReplicationSlot from './physical-replication-slot';
export * as publication from './publication';
export * as replicationSlot from './replication-slot';
export * as role from './role';
export * as schema from './schema';
export * as securityLabel from './security-label';
export * as server from './server';
export * as subscription from './subscription';
export * as userMapping from './user-mapping';
export * as dataPostgresqlSchemas from './data-postgresql-schemas';
export * as dataPostgresqlSequences from './data-postgresql-sequences';
export * as dataPostgresqlTables from './data-postgresql-tables';
export * as provider from './provider';
